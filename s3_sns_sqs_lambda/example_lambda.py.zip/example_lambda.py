import os


def handler(event, context):
    print("Hello")
    return "Hello world"
